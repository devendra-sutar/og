#!/bin/bash

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}🚀 KubeSage Agent Deployment and Testing Script${NC}"
echo "=================================================="

# Function to print colored output
print_status() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# Function to check prerequisites
check_prerequisites() {
    print_info "Checking prerequisites..."
    
    # Check if running as correct user
    if [ "$USER" != "nisha" ]; then
        print_warning "Running as user '$USER', expected 'nisha'"
        print_info "If you have permission issues, run the kubectl setup script first"
    fi
    
    # Check kubectl
    if ! command -v kubectl &> /dev/null; then
        print_error "kubectl is not installed or not in PATH"
        print_info "Run: ./setup-kubectl-user.sh to configure kubectl"
        exit 1
    fi
    print_status "kubectl is available"
    
    # Check cluster connection
    if ! kubectl cluster-info &> /dev/null; then
        print_error "Cannot connect to Kubernetes cluster"
        print_info "Possible solutions:"
        print_info "1. Run: ./setup-kubectl-user.sh"
        print_info "2. Check if k3s is running: sudo systemctl status k3s"
        print_info "3. Verify kubeconfig: ls -la ~/.kube/config"
        exit 1
    fi
    print_status "Connected to Kubernetes cluster"
    
    # Show cluster info
    print_info "Cluster nodes:"
    kubectl get nodes
    
    # Check Docker access
    if command -v docker &> /dev/null; then
        if docker version &> /dev/null; then
            print_status "Docker is available and accessible"
            CONTAINER_RUNTIME="docker"
        else
            print_warning "Docker is installed but not accessible"
            print_info "Try: newgrp docker  # or log out and back in"
            print_info "Or run: ./setup-kubectl-user.sh to fix Docker permissions"
            CONTAINER_RUNTIME=""
        fi
    elif command -v podman &> /dev/null; then
        print_status "Podman is available"
        CONTAINER_RUNTIME="podman"
    else
        print_warning "No container runtime found, skipping image build"
        CONTAINER_RUNTIME=""
    fi
}

# Function to build Docker image
build_image() {
    if [ -n "$CONTAINER_RUNTIME" ]; then
        print_info "Building Docker image with $CONTAINER_RUNTIME..."
        $CONTAINER_RUNTIME build -t kubesage-agent:latest .
        print_status "Docker image built successfully"
    else
        print_warning "Skipping image build - no container runtime available"
    fi
}

# Function to create source ConfigMap
create_source_configmap() {
    print_info "Creating source code ConfigMap..."
    
    # Check if required source files exist
    local required_files=("go.mod" "main.go" "agents.go" ".env")
    for file in "${required_files[@]}"; do
        if [ ! -f "$file" ]; then
            print_error "Required file $file not found"
            exit 1
        fi
    done
    
    # Create ConfigMap with source files
    if [ -f "go.sum" ]; then
        kubectl create configmap kubesage-agent-source \
            --from-file=go.mod \
            --from-file=go.sum \
            --from-file=main.go \
            --from-file=agents.go \
            --from-file=.env \
            --dry-run=client -o yaml > source-configmap.yaml
    else
        kubectl create configmap kubesage-agent-source \
            --from-file=go.mod \
            --from-file=main.go \
            --from-file=agents.go \
            --from-file=.env \
            --dry-run=client -o yaml > source-configmap.yaml
    fi
    
    print_status "Source ConfigMap created: source-configmap.yaml"
}

# Function to deploy all manifests
deploy_manifests() {
    print_info "Deploying Kubernetes manifests..."
    
    local manifests=("rbac.yaml" "configmap.yaml" "secret.yaml" "source-configmap.yaml" "service.yaml" "deployment.yaml")
    
    for manifest in "${manifests[@]}"; do
        if [ -f "$manifest" ]; then
            print_info "Applying $manifest..."
            kubectl apply -f "$manifest"
            print_status "$manifest applied successfully"
        else
            print_error "$manifest not found"
            exit 1
        fi
    done
}

# Function to wait for deployment and show status
wait_and_check_deployment() {
    print_info "Waiting for deployment to be ready..."
    
    # Wait for rollout to complete
    kubectl rollout status deployment/kubesage-agent --timeout=300s
    
    print_status "Deployment rollout completed"
    
    # Show pod status
    print_info "Pod status:"
    kubectl get pods -l app=kubesage-agent
    
    # Get pod name for detailed checks
    POD_NAME=$(kubectl get pods -l app=kubesage-agent -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
    
    if [ -n "$POD_NAME" ]; then
        print_info "Pod name: $POD_NAME"
        
        # Check if pod is running
        POD_STATUS=$(kubectl get pod "$POD_NAME" -o jsonpath='{.status.phase}')
        print_info "Pod status: $POD_STATUS"
        
        if [ "$POD_STATUS" = "Running" ]; then
            print_status "Pod is running successfully"
        else
            print_warning "Pod is not in Running state: $POD_STATUS"
        fi
    else
        print_error "No pods found with label app=kubesage-agent"
        return 1
    fi
}

# Function to test agent functionality
test_agent_functionality() {
    print_info "Testing agent functionality..."
    
    # Get pod name
    POD_NAME=$(kubectl get pods -l app=kubesage-agent -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
    
    if [ -z "$POD_NAME" ]; then
        print_error "No running pods found"
        return 1
    fi
    
    print_info "Testing with pod: $POD_NAME"
    
    # Test 1: Check if source files are mounted correctly
    print_info "Test 1: Checking source file mounting..."
    if kubectl exec "$POD_NAME" -- ls -la /source &>/dev/null; then
        kubectl exec "$POD_NAME" -- ls -la /source
        print_status "Source files mounted correctly"
    else
        print_error "Source files not accessible"
    fi
    
    # Test 2: Check application logs for initialization
    print_info "Test 2: Checking application logs..."
    sleep 10  # Wait for app to start
    
    LOGS=$(kubectl logs "$POD_NAME" --tail=50 2>/dev/null || echo "No logs available")
    echo "Recent logs:"
    echo "$LOGS"
    
    # Test 3: Check for specific log messages
    print_info "Test 3: Checking for key log messages..."
    
    if echo "$LOGS" | grep -q "Agent initialized\|WebSocket server\|Starting agent\|Connected to backend"; then
        print_status "Agent appears to be initializing correctly"
    else
        print_warning "Agent initialization messages not found in logs"
    fi
    
    # Test 4: Check connection to onboarding service
    print_info "Test 4: Checking backend connectivity..."
    if echo "$LOGS" | grep -q "Error\|Failed\|Connection refused\|timeout"; then
        print_warning "Found error messages in logs - connection issues possible"
        echo "Error patterns found:"
        echo "$LOGS" | grep -E "(Error|Failed|Connection refused|timeout)" || true
    else
        print_status "No obvious connection errors found"
    fi
}

# Function to show final status and useful commands
show_final_status() {
    print_info "Final deployment status:"
    
    echo ""
    echo "📊 Deployment Summary:"
    kubectl get deployment kubesage-agent
    echo ""
    kubectl get pods -l app=kubesage-agent
    echo ""
    kubectl get svc kubesage-agent-service 2>/dev/null || print_warning "Service not found"
    
    echo ""
    print_info "Useful commands for monitoring and debugging:"
    echo "🔍 Watch logs in real-time:"
    echo "   kubectl logs -l app=kubesage-agent -f"
    echo ""
    echo "🔍 Check pod status:"
    echo "   kubectl get pods -l app=kubesage-agent"
    echo ""
    echo "🔍 Get detailed pod information:"
    echo "   kubectl describe pod -l app=kubesage-agent"
    echo ""
    echo "🔍 Execute commands in pod:"
    POD_NAME=$(kubectl get pods -l app=kubesage-agent -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "POD_NAME")
    echo "   kubectl exec -it $POD_NAME -- /bin/sh"
    echo ""
    echo "🔧 Update secrets (replace values):"
    echo "   kubectl patch secret kubesage-agent-secret -p='{\"data\":{\"AGENT_ID\":\"'$(echo -n 'your-new-agent-id' | base64)'\"}}"
    echo "   kubectl patch secret kubesage-agent-secret -p='{\"data\":{\"API_KEY\":\"'$(echo -n 'your-new-api-key' | base64)'\"}}"
    echo ""
    echo "🔄 Restart deployment:"
    echo "   kubectl rollout restart deployment kubesage-agent"
    echo ""
    echo "🗑️  Clean up deployment:"
    echo "   kubectl delete -f ."
}

# Function to run extended monitoring
extended_monitoring() {
    print_info "Running extended monitoring (2 minutes)..."
    
    POD_NAME=$(kubectl get pods -l app=kubesage-agent -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
    
    if [ -z "$POD_NAME" ]; then
        print_error "No pod found for monitoring"
        return 1
    fi
    
    # Monitor for 2 minutes
    for i in {1..4}; do
        print_info "Monitoring cycle $i/4 (30 seconds each)..."
        sleep 30
        
        print_info "Pod status check:"
        kubectl get pods -l app=kubesage-agent
        
        print_info "Recent logs:"
        kubectl logs "$POD_NAME" --tail=10 2>/dev/null || print_warning "Could not fetch logs"
        
        # Check for specific patterns
        RECENT_LOGS=$(kubectl logs "$POD_NAME" --tail=20 2>/dev/null || echo "")
        if echo "$RECENT_LOGS" | grep -q "Agent initialized\|Connected\|WebSocket server"; then
            print_status "Agent appears to be functioning correctly"
        elif echo "$RECENT_LOGS" | grep -q "Error\|Failed\|Panic"; then
            print_warning "Errors detected in recent logs"
        fi
        
        echo "----------------------------------------"
    done
}

# Main execution function
main() {
    echo "Starting KubeSage Agent deployment and testing..."
    echo ""
    
    check_prerequisites
    echo ""
    
    build_image
    echo ""
    
    create_source_configmap
    echo ""
    
    deploy_manifests
    echo ""
    
    wait_and_check_deployment
    echo ""
    
    test_agent_functionality
    echo ""
    
    # Ask user if they want extended monitoring
    read -p "Do you want to run extended monitoring for 2 minutes? (y/n): " -n 1 -r
    echo ""
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        extended_monitoring
        echo ""
    fi
    
    show_final_status
    
    echo ""
    print_status "🎉 KubeSage Agent deployment and testing completed!"
}

# Handle script arguments
case "${1:-}" in
    --help|-h)
        echo "KubeSage Agent Deployment and Testing Script"
        echo ""
        echo "Usage: $0 [--help|--monitor-only]"
        echo ""
        echo "Options:"
        echo "  --help, -h        Show this help message"
        echo "  --monitor-only    Skip deployment, only monitor existing deployment"
        echo ""
        exit 0
        ;;
    --monitor-only)
        print_info "Monitoring existing deployment only..."
        extended_monitoring
        exit 0
        ;;
    *)
        main "$@"
        ;;
esac