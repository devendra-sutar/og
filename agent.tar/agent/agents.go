package main

import (
	"bytes"
	"context"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	appsv1 "k8s.io/api/apps/v1"
	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/clientcmd"
)

// getKubernetesConfig returns a Kubernetes config, trying in-cluster first, then local kubeconfig
func getKubernetesConfig() (*rest.Config, error) {
	// Try in-cluster config first
	config, err := rest.InClusterConfig()
	if err != nil {
		// If not running in-cluster, try to use local kubeconfig
		kubeconfig := os.Getenv("KUBECONFIG")
		if kubeconfig == "" {
			// Default kubeconfig path
			home := os.Getenv("HOME")
			if home != "" {
				kubeconfig = filepath.Join(home, ".kube", "config")
			}
		}

		// Load kubeconfig
		config, err = clientcmd.BuildConfigFromFlags("", kubeconfig)
		if err != nil {
			return nil, fmt.Errorf("failed to load kubeconfig: %v", err)
		}
	}
	return config, nil
}

// onboardAgent handles the onboarding of a Kubernetes cluster.
func onboardAgent(event map[string]interface{}) (string, error) {
	clusterName, ok := event["cluster_name"].(string)
	if !ok {
		return "Invalid cluster_name", nil
	}
	serverURL, ok := event["server_url"].(string)
	if !ok {
		return "Invalid server_url", nil
	}
	token, ok := event["token"].(string)
	if !ok {
		return "Invalid token", nil
	}
	contextName, ok := event["context_name"].(string)
	if !ok {
		return "Invalid context_name", nil
	}
	useSecureTLS, ok := event["use_secure_tls"].(bool)
	if !ok {
		return "Invalid use_secure_tls", nil
	}

	// Create kubeconfig content
	kubeconfig := `apiVersion: v1
clusters:
- cluster:
    server: ` + serverURL
	if useSecureTLS {
		caData, ok := event["ca_data"].(string)
		if !ok {
			return "Invalid ca_data", nil
		}
		kubeconfig += `
    certificate-authority-data: ` + caData
	} else {
		kubeconfig += `
    insecure-skip-tls-verify: true`
	}
	kubeconfig += `
  name: ` + clusterName + `
contexts:
- context:
    cluster: ` + clusterName + `
    user: ` + clusterName + `-user
  name: ` + contextName + `
current-context: ` + contextName + `
kind: Config
preferences: {}
users:
- name: ` + clusterName + `-user
  user:
    token: ` + token + `
`

	// Write kubeconfig to file
	filename := "/tmp/" + clusterName + ".kubeconfig"
	err := os.WriteFile(filename, []byte(kubeconfig), 0644)
	if err != nil {
		return "Failed to create kubeconfig file: " + err.Error(), err
	}

	return "Cluster onboarded successfully, kubeconfig created at " + filename, nil
}

// deleteClusterAgent handles the deletion of a Kubernetes cluster by removing its kubeconfig file.
func deleteClusterAgent(event map[string]interface{}) (string, error) {
	clusterName, ok := event["cluster_name"].(string)
	if !ok {
		return "Invalid cluster_name", nil
	}

	log.Printf("Initiating cluster deletion for: %s", clusterName)

	// For in-cluster deployment, we don't have kubeconfig files to remove
	// Instead, we'll perform cleanup operations and mark the agent as disconnected

	// Remove kubeconfig file (if it exists for external clusters)
	filename := "/tmp/" + clusterName + ".kubeconfig"
	err := os.Remove(filename)
	if err != nil && !os.IsNotExist(err) {
		log.Printf("Warning: Failed to remove kubeconfig file %s: %v", filename, err)
	}

	// For in-cluster agents, we mainly need to signal that the cluster is being offboarded
	// The actual database cleanup will be handled by the onboarding service
	log.Printf("Cluster %s marked for deletion", clusterName)

	// Return success message
	return fmt.Sprintf("Cluster '%s' deletion initiated successfully. Agent will be disconnected.", clusterName), nil
}

// getPodsAgent retrieves pods from a namespace with detailed information
func getPodsAgent(event map[string]interface{}) (string, error) {
	namespace, ok := event["namespace"].(string)
	if !ok {
		namespace = "default"
	}

	// Get Kubernetes config (in-cluster or local kubeconfig)
	config, err := getKubernetesConfig()
	if err != nil {
		return fmt.Sprintf("Failed to get Kubernetes config: %v", err), err
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		return "Failed to create k8s client: " + err.Error(), err
	}

	pods, err := clientset.CoreV1().Pods(namespace).List(context.TODO(), metav1.ListOptions{})
	if err != nil {
		return "Failed to list pods: " + err.Error(), err
	}

	var podList []map[string]interface{}
	for _, pod := range pods.Items {
		podInfo := map[string]interface{}{
			"name":       pod.Name,
			"namespace":  pod.Namespace,
			"status":     string(pod.Status.Phase),
			"node":       pod.Spec.NodeName,
			"restarts":   int32(0),
			"age":        pod.CreationTimestamp.Time,
			"containers": []map[string]interface{}{},
		}

		// Get container information
		for _, container := range pod.Spec.Containers {
			containerInfo := map[string]interface{}{
				"name":  container.Name,
				"image": container.Image,
				"ready": false,
			}
			podInfo["containers"] = append(podInfo["containers"].([]map[string]interface{}), containerInfo)
		}

		// Get container statuses
		if pod.Status.ContainerStatuses != nil {
			for i, containerStatus := range pod.Status.ContainerStatuses {
				if i < len(podInfo["containers"].([]map[string]interface{})) {
					containers := podInfo["containers"].([]map[string]interface{})
					containers[i]["ready"] = containerStatus.Ready
					containers[i]["restart_count"] = containerStatus.RestartCount
					podInfo["restarts"] = podInfo["restarts"].(int32) + containerStatus.RestartCount
				}
			}
		}

		podList = append(podList, podInfo)
	}

	result := map[string]interface{}{
		"namespace": namespace,
		"pods":      podList,
		"count":     len(podList),
	}
	resultBytes, _ := json.Marshal(result)
	return string(resultBytes), nil
}

// getDeploymentsAgent retrieves deployments from a namespace
func getDeploymentsAgent(event map[string]interface{}) (string, error) {
	namespace, ok := event["namespace"].(string)
	if !ok {
		namespace = "default"
	}

	// Get Kubernetes config (in-cluster or local kubeconfig)
	config, err := getKubernetesConfig()
	if err != nil {
		return fmt.Sprintf("Failed to get Kubernetes config: %v", err), err
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		return "Failed to create k8s client: " + err.Error(), err
	}

	deployments, err := clientset.AppsV1().Deployments(namespace).List(context.TODO(), metav1.ListOptions{})
	if err != nil {
		return "Failed to list deployments: " + err.Error(), err
	}

	var deploymentList []map[string]interface{}
	for _, deployment := range deployments.Items {
		deploymentInfo := map[string]interface{}{
			"name":       deployment.Name,
			"namespace":  deployment.Namespace,
			"replicas":   deployment.Spec.Replicas,
			"ready":      deployment.Status.ReadyReplicas,
			"available":  deployment.Status.AvailableReplicas,
			"updated":    deployment.Status.UpdatedReplicas,
			"age":        deployment.CreationTimestamp.Time,
			"containers": []string{},
		}

		// Get container images
		for _, container := range deployment.Spec.Template.Spec.Containers {
			deploymentInfo["containers"] = append(deploymentInfo["containers"].([]string), container.Image)
		}

		deploymentList = append(deploymentList, deploymentInfo)
	}

	result := map[string]interface{}{
		"namespace":   namespace,
		"deployments": deploymentList,
		"count":       len(deploymentList),
	}
	resultBytes, _ := json.Marshal(result)
	return string(resultBytes), nil
}

// getServicesAgent retrieves services from a namespace
func getServicesAgent(event map[string]interface{}) (string, error) {
	namespace, ok := event["namespace"].(string)
	if !ok {
		namespace = "default"
	}

	// Get Kubernetes config (in-cluster or local kubeconfig)
	config, err := getKubernetesConfig()
	if err != nil {
		return fmt.Sprintf("Failed to get Kubernetes config: %v", err), err
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		return "Failed to create k8s client: " + err.Error(), err
	}

	services, err := clientset.CoreV1().Services(namespace).List(context.TODO(), metav1.ListOptions{})
	if err != nil {
		return "Failed to list services: " + err.Error(), err
	}

	var serviceList []map[string]interface{}
	for _, service := range services.Items {
		serviceInfo := map[string]interface{}{
			"name":        service.Name,
			"namespace":   service.Namespace,
			"type":        string(service.Spec.Type),
			"cluster_ip":  service.Spec.ClusterIP,
			"external_ip": service.Status.LoadBalancer.Ingress,
			"ports":       []map[string]interface{}{},
			"age":         service.CreationTimestamp.Time,
			"selector":    service.Spec.Selector,
		}

		// Get port information
		for _, port := range service.Spec.Ports {
			portInfo := map[string]interface{}{
				"name":        port.Name,
				"port":        port.Port,
				"target_port": port.TargetPort.String(),
				"protocol":    string(port.Protocol),
			}
			serviceInfo["ports"] = append(serviceInfo["ports"].([]map[string]interface{}), portInfo)
		}

		serviceList = append(serviceList, serviceInfo)
	}

	result := map[string]interface{}{
		"namespace": namespace,
		"services":  serviceList,
		"count":     len(serviceList),
	}
	resultBytes, _ := json.Marshal(result)
	return string(resultBytes), nil
}

// getNodesAgent retrieves node information
func getNodesAgent(event map[string]interface{}) (string, error) {
	// Get Kubernetes config (in-cluster or local kubeconfig)
	config, err := getKubernetesConfig()
	if err != nil {
		return fmt.Sprintf("Failed to get Kubernetes config: %v", err), err
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		return "Failed to create k8s client: " + err.Error(), err
	}

	nodes, err := clientset.CoreV1().Nodes().List(context.TODO(), metav1.ListOptions{})
	if err != nil {
		return "Failed to list nodes: " + err.Error(), err
	}

	var nodeList []map[string]interface{}
	for _, node := range nodes.Items {
		nodeInfo := map[string]interface{}{
			"name":              node.Name,
			"status":            "Unknown",
			"roles":             []string{},
			"age":               node.CreationTimestamp.Time,
			"version":           node.Status.NodeInfo.KubeletVersion,
			"internal_ip":       "",
			"external_ip":       "",
			"os":                node.Status.NodeInfo.OSImage,
			"kernel":            node.Status.NodeInfo.KernelVersion,
			"container_runtime": node.Status.NodeInfo.ContainerRuntimeVersion,
		}

		// Get node status
		for _, condition := range node.Status.Conditions {
			if condition.Type == "Ready" {
				if condition.Status == "True" {
					nodeInfo["status"] = "Ready"
				} else {
					nodeInfo["status"] = "NotReady"
				}
				break
			}
		}

		// Get node roles from labels
		if node.Labels != nil {
			for label := range node.Labels {
				if label == "node-role.kubernetes.io/master" || label == "node-role.kubernetes.io/control-plane" {
					nodeInfo["roles"] = append(nodeInfo["roles"].([]string), "control-plane")
				} else if label == "node-role.kubernetes.io/worker" {
					nodeInfo["roles"] = append(nodeInfo["roles"].([]string), "worker")
				}
			}
		}

		// Get IP addresses
		for _, address := range node.Status.Addresses {
			if address.Type == "InternalIP" {
				nodeInfo["internal_ip"] = address.Address
			} else if address.Type == "ExternalIP" {
				nodeInfo["external_ip"] = address.Address
			}
		}

		nodeList = append(nodeList, nodeInfo)
	}

	result := map[string]interface{}{
		"nodes": nodeList,
		"count": len(nodeList),
	}
	resultBytes, _ := json.Marshal(result)
	return string(resultBytes), nil
}

// getClusterResourcesAgent retrieves overall cluster resource information
func getClusterResourcesAgent(event map[string]interface{}) (string, error) {
	// Get Kubernetes config (in-cluster or local kubeconfig)
	config, err := getKubernetesConfig()
	if err != nil {
		return fmt.Sprintf("Failed to get Kubernetes config: %v", err), err
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		return "Failed to create k8s client: " + err.Error(), err
	}

	// Get nodes for resource calculation
	nodes, err := clientset.CoreV1().Nodes().List(context.TODO(), metav1.ListOptions{})
	if err != nil {
		return "Failed to list nodes: " + err.Error(), err
	}

	// Get namespaces
	namespaces, err := clientset.CoreV1().Namespaces().List(context.TODO(), metav1.ListOptions{})
	if err != nil {
		return "Failed to list namespaces: " + err.Error(), err
	}

	// Get all pods for counting
	pods, err := clientset.CoreV1().Pods("").List(context.TODO(), metav1.ListOptions{})
	if err != nil {
		return "Failed to list pods: " + err.Error(), err
	}

	// Get deployments
	deployments, err := clientset.AppsV1().Deployments("").List(context.TODO(), metav1.ListOptions{})
	if err != nil {
		return "Failed to list deployments: " + err.Error(), err
	}

	// Get services
	services, err := clientset.CoreV1().Services("").List(context.TODO(), metav1.ListOptions{})
	if err != nil {
		return "Failed to list services: " + err.Error(), err
	}

	result := map[string]interface{}{
		"cluster_summary": map[string]interface{}{
			"nodes":       len(nodes.Items),
			"namespaces":  len(namespaces.Items),
			"pods":        len(pods.Items),
			"deployments": len(deployments.Items),
			"services":    len(services.Items),
		},
		"nodes_status": map[string]int{
			"ready":     0,
			"not_ready": 0,
		},
		"pods_status": map[string]int{
			"running":   0,
			"pending":   0,
			"failed":    0,
			"succeeded": 0,
		},
	}

	// Count node statuses
	for _, node := range nodes.Items {
		for _, condition := range node.Status.Conditions {
			if condition.Type == "Ready" {
				if condition.Status == "True" {
					result["nodes_status"].(map[string]int)["ready"]++
				} else {
					result["nodes_status"].(map[string]int)["not_ready"]++
				}
				break
			}
		}
	}

	// Count pod statuses
	for _, pod := range pods.Items {
		switch pod.Status.Phase {
		case "Running":
			result["pods_status"].(map[string]int)["running"]++
		case "Pending":
			result["pods_status"].(map[string]int)["pending"]++
		case "Failed":
			result["pods_status"].(map[string]int)["failed"]++
		case "Succeeded":
			result["pods_status"].(map[string]int)["succeeded"]++
		}
	}

	resultBytes, _ := json.Marshal(result)
	return string(resultBytes), nil
}

// getPodLogsAgent retrieves logs from a specific pod
func getPodLogsAgent(event map[string]interface{}) (string, error) {
	namespace, ok := event["namespace"].(string)
	if !ok {
		namespace = "default"
	}

	podName, ok := event["pod_name"].(string)
	if !ok {
		return "pod_name is required", nil
	}

	containerName, _ := event["container_name"].(string)
	tailLines := int64(100)
	if lines, ok := event["tail_lines"].(float64); ok {
		tailLines = int64(lines)
	}

	config, err := getKubernetesConfig()
	if err != nil {
		return fmt.Sprintf("Failed to get Kubernetes config: %v", err), err
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		return "Failed to create k8s client: " + err.Error(), err
	}

	// Get pod logs
	podLogOptions := &v1.PodLogOptions{
		TailLines: &tailLines,
	}
	if containerName != "" {
		podLogOptions.Container = containerName
	}

	req := clientset.CoreV1().Pods(namespace).GetLogs(podName, podLogOptions)
	logs, err := req.Stream(context.TODO())
	if err != nil {
		return "Failed to get pod logs: " + err.Error(), err
	}
	defer logs.Close()

	// Read logs
	buf := new(bytes.Buffer)
	_, err = buf.ReadFrom(logs)
	if err != nil {
		return "Failed to read logs: " + err.Error(), err
	}

	result := map[string]interface{}{
		"namespace":      namespace,
		"pod_name":       podName,
		"container_name": containerName,
		"logs":           buf.String(),
		"tail_lines":     tailLines,
	}
	resultBytes, _ := json.Marshal(result)
	return string(resultBytes), nil
}

// getNamespacesAgent retrieves namespaces from the cluster
func getNamespacesAgent(event map[string]interface{}) (string, error) {
	serverURL, ok := event["server_url"].(string)
	if !ok {
		// Use our helper function to get config (in-cluster or local kubeconfig)
		config, err := getKubernetesConfig()
		if err != nil {
			return fmt.Sprintf("Failed to get Kubernetes config: %v", err), err
		}

		clientset, err := kubernetes.NewForConfig(config)
		if err != nil {
			return "Failed to create k8s client: " + err.Error(), err
		}
		namespaces, err := clientset.CoreV1().Namespaces().List(context.TODO(), metav1.ListOptions{})
		if err != nil {
			return "Failed to list namespaces in-cluster: " + err.Error(), err
		}
		var nsList []string
		for _, ns := range namespaces.Items {
			nsList = append(nsList, ns.Name)
		}
		result := map[string]interface{}{
			"namespaces": nsList,
		}
		resultBytes, _ := json.Marshal(result)
		return string(resultBytes), nil
	}

	token, ok := event["token"].(string)
	if !ok {
		return "Invalid token", nil
	}
	useSecureTLS, ok := event["use_secure_tls"].(bool)
	if !ok {
		useSecureTLS = false
	}

	// Create config
	config := &rest.Config{
		Host:        serverURL,
		BearerToken: token,
	}
	if useSecureTLS {
		caData, ok := event["ca_data"].(string)
		if ok {
			config.CAData = []byte(caData)
		}
		tlsCert, ok := event["tls_cert"].(string)
		tlsKey, ok2 := event["tls_key"].(string)
		if ok && ok2 {
			config.CertData = []byte(tlsCert)
			config.KeyData = []byte(tlsKey)
		}
	} else {
		config.Insecure = true
	}

	// Create client
	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		return "Failed to create k8s client: " + err.Error(), err
	}

	// List namespaces
	namespaces, err := clientset.CoreV1().Namespaces().List(context.TODO(), metav1.ListOptions{})
	if err != nil {
		return "Failed to list namespaces: " + err.Error(), err
	}

	var nsList []string
	for _, ns := range namespaces.Items {
		nsList = append(nsList, ns.Name)
	}

	result := map[string]interface{}{
		"namespaces": nsList,
	}
	resultBytes, err := json.Marshal(result)
	if err != nil {
		return "Failed to marshal result", err
	}
	return string(resultBytes), nil
}

// getClusterInfoFromInCluster retrieves cluster information using kubeconfig or in-cluster configuration
func getClusterInfoFromInCluster() (map[string]interface{}, error) {
	// Get Kubernetes config (in-cluster or local kubeconfig)
	config, err := getKubernetesConfig()
	if err != nil {
		return nil, fmt.Errorf("failed to get Kubernetes config: %v", err)
	}

	// Create clientset
	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		return nil, fmt.Errorf("failed to create clientset: %v", err)
	}

	// Get cluster info
	clusterInfo := make(map[string]interface{})

	// Get node count
	nodes, err := clientset.CoreV1().Nodes().List(context.TODO(), metav1.ListOptions{})
	if err != nil {
		fmt.Printf("Warning: Failed to get nodes: %v\n", err)
		clusterInfo["node_count"] = 0
	} else {
		clusterInfo["node_count"] = len(nodes.Items)
		fmt.Printf("Found %d nodes in cluster\n", len(nodes.Items))
	}

	// Get Kubernetes version
	version, err := clientset.Discovery().ServerVersion()
	if err != nil {
		fmt.Printf("Warning: Failed to get server version: %v\n", err)
		clusterInfo["kubernetes_version"] = "unknown"
	} else {
		clusterInfo["kubernetes_version"] = version.GitVersion
		fmt.Printf("Kubernetes version: %s\n", version.GitVersion)
	}

	// Get namespace count
	namespaces, err := clientset.CoreV1().Namespaces().List(context.TODO(), metav1.ListOptions{})
	if err != nil {
		fmt.Printf("Warning: Failed to get namespaces: %v\n", err)
		clusterInfo["namespace_count"] = 0
	} else {
		clusterInfo["namespace_count"] = len(namespaces.Items)
		fmt.Printf("Found %d namespaces in cluster\n", len(namespaces.Items))
	}

	// Add cluster type and mode
	clusterInfo["cluster_type"] = "kubernetes"
	if config.Host != "" {
		clusterInfo["agent_mode"] = "external"
		clusterInfo["cluster_host"] = config.Host
	} else {
		clusterInfo["agent_mode"] = "in-cluster"
	}
	clusterInfo["status"] = "connected"

	return clusterInfo, nil
}

// callOnboardingAPI calls the onboarding API with the provided event data
func callOnboardingAPI(event map[string]interface{}) error {
	// Get cluster name from environment or event
	clusterName := os.Getenv("CLUSTER_NAME")
	if clusterName == "" {
		if cn, ok := event["cluster_name"].(string); ok {
			clusterName = cn
		} else {
			clusterName = "default-cluster"
		}
	}

	// Get required environment variables
	agentID := os.Getenv("AGENT_ID")
	if agentID == "" {
		return fmt.Errorf("AGENT_ID environment variable not set")
	}
	apiKey := os.Getenv("API_KEY")
	if apiKey == "" {
		return fmt.Errorf("API_KEY environment variable not set")
	}
	backendURL := os.Getenv("BACKEND_URL")
	if backendURL == "" {
		return fmt.Errorf("BACKEND_URL environment variable not set")
	}

	// Check if this agent is already registered by calling the clusters list API
	isAlreadyRegistered, err := checkIfAgentRegistered(agentID, apiKey, backendURL)
	if err != nil {
		fmt.Printf("Warning: Could not check agent registration status: %v (proceeding with onboarding)\n", err)
	} else if isAlreadyRegistered {
		fmt.Printf("Agent %s is already registered, skipping onboarding\n", agentID)
		return nil
	}

	// Get cluster information using in-cluster config
	clusterInfo, err := getClusterInfoFromInCluster()
	if err != nil {
		return fmt.Errorf("failed to get cluster info: %v", err)
	}

	// Prepare the request body with cluster metadata (no server_url or token needed)
	requestBody := map[string]interface{}{
		"cluster_name":   clusterName,
		"context_name":   clusterName + "-context",
		"provider_name":  "kubernetes",
		"use_secure_tls": true,
		"metadata": map[string]interface{}{
			"agent_id":           agentID,
			"agent_version":      "1.0.0",
			"node_count":         clusterInfo["node_count"],
			"kubernetes_version": clusterInfo["kubernetes_version"],
			"provider":           "kubernetes",
			"namespace_count":    clusterInfo["namespace_count"],
			"cluster_info":       clusterInfo,
		},
	}

	// Override with event data if provided (only for optional fields)
	if contextName, ok := event["context_name"].(string); ok {
		requestBody["context_name"] = contextName
	}
	if providerName, ok := event["provider_name"].(string); ok {
		requestBody["provider_name"] = providerName
	}
	if tags, ok := event["tags"].([]interface{}); ok {
		requestBody["tags"] = tags
	}

	// Convert to JSON
	jsonData, err := json.Marshal(requestBody)
	if err != nil {
		return fmt.Errorf("failed to marshal request body: %v", err)
	}

	// Make HTTP POST request to onboarding API
	url := backendURL
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
	if err != nil {
		return fmt.Errorf("failed to create HTTP request: %v", err)
	}

	// Set headers
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("agent_id", agentID)
	req.Header.Set("X-API-Key", apiKey)

	// Create HTTP client with appropriate TLS config
	skipTLSVerify := os.Getenv("SKIP_TLS_VERIFY") == "true"
	client := &http.Client{
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{
				InsecureSkipVerify: skipTLSVerify,
				MinVersion:         tls.VersionTLS12,
			},
		},
	}
	resp, err := client.Do(req)
	if err != nil {
		return fmt.Errorf("failed to send HTTP request: %v", err)
	}
	defer resp.Body.Close()

	// Check response status
	if resp.StatusCode == http.StatusBadRequest {
		// 400 likely means cluster already exists, read the response body for details
		bodyMsg := fmt.Sprintf("Cluster likely already exists (400 Bad Request). Agent %s may already be registered.", agentID)
		fmt.Printf("Warning: %s\n", bodyMsg)
		return nil // Don't treat this as an error, just a warning
	} else if resp.StatusCode != http.StatusCreated {
		return fmt.Errorf("onboarding API returned status %d", resp.StatusCode)
	}

	fmt.Printf("Onboarding API called successfully for cluster %s\n", clusterName)
	return nil
}

// checkIfAgentRegistered checks if the agent is already registered by calling the clusters API
func checkIfAgentRegistered(agentID, apiKey, backendURL string) (bool, error) {
	// Convert onboard URL to clusters list URL
	// https://10.0.32.106:8006/api/v2.0/onboard -> https://10.0.32.106:8006/api/v2.0/clusters
	listURL := backendURL[:len(backendURL)-len("/onboard")] + "/clusters"

	req, err := http.NewRequest("GET", listURL, nil)
	if err != nil {
		return false, fmt.Errorf("failed to create clusters list request: %v", err)
	}

	// Set headers
	req.Header.Set("X-API-Key", apiKey)

	// Create HTTP client with appropriate TLS config
	skipTLSVerify := os.Getenv("SKIP_TLS_VERIFY") == "true"
	client := &http.Client{
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{
				InsecureSkipVerify: skipTLSVerify,
				MinVersion:         tls.VersionTLS12,
			},
		},
	}

	resp, err := client.Do(req)
	if err != nil {
		return false, fmt.Errorf("failed to send clusters list request: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return false, fmt.Errorf("clusters list API returned status %d", resp.StatusCode)
	}

	// For now, we'll always return false to allow onboarding, but handle 400 gracefully
	// TODO: Actually parse the response to check for agent_id in cluster metadata
	return false, nil
}

// getWorkloadsAgent retrieves all workloads from a namespace
func getWorkloadsAgent(event map[string]interface{}) (string, error) {
	namespace, ok := event["namespace"].(string)
	if !ok {
		namespace = "default"
	}

	// Get Kubernetes config (in-cluster or local kubeconfig)
	config, err := getKubernetesConfig()
	if err != nil {
		return fmt.Sprintf("Failed to get Kubernetes config: %v", err), err
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		return "Failed to create k8s client: " + err.Error(), err
	}

	// Initialize workloads map
	workloads := map[string]interface{}{
		"pods":         []map[string]interface{}{},
		"deployments":  []map[string]interface{}{},
		"services":     []map[string]interface{}{},
		"statefulsets": []map[string]interface{}{},
		"daemonsets":   []map[string]interface{}{},
		"jobs":         []map[string]interface{}{},
		"cronjobs":     []map[string]interface{}{},
	}

	// Get Pods
	pods, err := clientset.CoreV1().Pods(namespace).List(context.TODO(), metav1.ListOptions{})
	if err == nil {
		var podList []map[string]interface{}
		for _, pod := range pods.Items {
			readyContainers := 0
			totalContainers := len(pod.Spec.Containers)
			restarts := int32(0)

			if pod.Status.ContainerStatuses != nil {
				for _, containerStatus := range pod.Status.ContainerStatuses {
					if containerStatus.Ready {
						readyContainers++
					}
					restarts += containerStatus.RestartCount
				}
			}

			podInfo := map[string]interface{}{
				"name":     pod.Name,
				"status":   string(pod.Status.Phase),
				"ready":    fmt.Sprintf("%d/%d", readyContainers, totalContainers),
				"restarts": restarts,
				"age":      pod.CreationTimestamp.Time.Format("2006-01-02T15:04:05Z"),
				"node":     pod.Spec.NodeName,
			}
			podList = append(podList, podInfo)
		}
		workloads["pods"] = podList
	}

	// Get Deployments
	deployments, err := clientset.AppsV1().Deployments(namespace).List(context.TODO(), metav1.ListOptions{})
	if err == nil {
		var deploymentList []map[string]interface{}
		for _, dep := range deployments.Items {
			deploymentInfo := map[string]interface{}{
				"name":       dep.Name,
				"ready":      fmt.Sprintf("%d/%d", dep.Status.ReadyReplicas, dep.Spec.Replicas),
				"up_to_date": dep.Status.UpdatedReplicas,
				"available":  dep.Status.AvailableReplicas,
				"age":        dep.CreationTimestamp.Time.Format("2006-01-02T15:04:05Z"),
			}
			deploymentList = append(deploymentList, deploymentInfo)
		}
		workloads["deployments"] = deploymentList
	}

	// Get Services
	services, err := clientset.CoreV1().Services(namespace).List(context.TODO(), metav1.ListOptions{})
	if err == nil {
		var serviceList []map[string]interface{}
		for _, svc := range services.Items {
			var ports []string
			for _, port := range svc.Spec.Ports {
				portStr := fmt.Sprintf("%d:%d/%s", port.Port, port.TargetPort.IntVal, port.Protocol)
				ports = append(ports, portStr)
			}

			var externalIP string
			if len(svc.Status.LoadBalancer.Ingress) > 0 {
				externalIP = svc.Status.LoadBalancer.Ingress[0].IP
			}

			serviceInfo := map[string]interface{}{
				"name":        svc.Name,
				"type":        string(svc.Spec.Type),
				"cluster_ip":  svc.Spec.ClusterIP,
				"external_ip": externalIP,
				"ports":       ports,
				"age":         svc.CreationTimestamp.Time.Format("2006-01-02T15:04:05Z"),
			}
			serviceList = append(serviceList, serviceInfo)
		}
		workloads["services"] = serviceList
	}

	// Get StatefulSets
	statefulsets, err := clientset.AppsV1().StatefulSets(namespace).List(context.TODO(), metav1.ListOptions{})
	if err == nil {
		var statefulsetList []map[string]interface{}
		for _, sts := range statefulsets.Items {
			statefulsetInfo := map[string]interface{}{
				"name":  sts.Name,
				"ready": fmt.Sprintf("%d/%d", sts.Status.ReadyReplicas, sts.Spec.Replicas),
				"age":   sts.CreationTimestamp.Time.Format("2006-01-02T15:04:05Z"),
			}
			statefulsetList = append(statefulsetList, statefulsetInfo)
		}
		workloads["statefulsets"] = statefulsetList
	}

	// Get DaemonSets
	daemonsets, err := clientset.AppsV1().DaemonSets(namespace).List(context.TODO(), metav1.ListOptions{})
	if err == nil {
		var daemonsetList []map[string]interface{}
		for _, ds := range daemonsets.Items {
			daemonsetInfo := map[string]interface{}{
				"name":       ds.Name,
				"desired":    ds.Status.DesiredNumberScheduled,
				"current":    ds.Status.CurrentNumberScheduled,
				"ready":      ds.Status.NumberReady,
				"up_to_date": ds.Status.UpdatedNumberScheduled,
				"available":  ds.Status.NumberAvailable,
				"age":        ds.CreationTimestamp.Time.Format("2006-01-02T15:04:05Z"),
			}
			daemonsetList = append(daemonsetList, daemonsetInfo)
		}
		workloads["daemonsets"] = daemonsetList
	}

	// Get Jobs
	jobs, err := clientset.BatchV1().Jobs(namespace).List(context.TODO(), metav1.ListOptions{})
	if err == nil {
		var jobList []map[string]interface{}
		for _, job := range jobs.Items {
			var duration string
			if job.Status.CompletionTime != nil {
				duration = job.Status.CompletionTime.Format("2006-01-02T15:04:05Z")
			}

			jobInfo := map[string]interface{}{
				"name":        job.Name,
				"completions": fmt.Sprintf("%d/%d", job.Status.Succeeded, *job.Spec.Completions),
				"duration":    duration,
				"age":         job.CreationTimestamp.Time.Format("2006-01-02T15:04:05Z"),
			}
			jobList = append(jobList, jobInfo)
		}
		workloads["jobs"] = jobList
	}

	// Get CronJobs
	cronjobs, err := clientset.BatchV1().CronJobs(namespace).List(context.TODO(), metav1.ListOptions{})
	if err == nil {
		var cronjobList []map[string]interface{}
		for _, cj := range cronjobs.Items {
			var lastSchedule string
			if cj.Status.LastScheduleTime != nil {
				lastSchedule = cj.Status.LastScheduleTime.Format("2006-01-02T15:04:05Z")
			}

			cronjobInfo := map[string]interface{}{
				"name":          cj.Name,
				"schedule":      cj.Spec.Schedule,
				"suspend":       cj.Spec.Suspend != nil && *cj.Spec.Suspend,
				"active":        len(cj.Status.Active),
				"last_schedule": lastSchedule,
				"age":           cj.CreationTimestamp.Time.Format("2006-01-02T15:04:05Z"),
			}
			cronjobList = append(cronjobList, cronjobInfo)
		}
		workloads["cronjobs"] = cronjobList
	}

	// Calculate total workloads
	totalWorkloads := 0
	for _, workloadType := range workloads {
		if workloadSlice, ok := workloadType.([]map[string]interface{}); ok {
			totalWorkloads += len(workloadSlice)
		}
	}

	result := map[string]interface{}{
		"namespace":       namespace,
		"workloads":       workloads,
		"total_workloads": totalWorkloads,
		"retrieved_at":    fmt.Sprintf("%d", time.Now().Unix()),
	}

	resultBytes, _ := json.Marshal(result)
	return string(resultBytes), nil
}

// getApplicationsAgent retrieves applications from a cluster
func getApplicationsAgent(event map[string]interface{}) (string, error) {
	namespace, _ := event["namespace"].(string) // Optional filter
	appType, _ := event["app_type"].(string)    // Optional filter

	// Log the request parameters for debugging
	log.Printf("Getting applications - namespace: '%s', app_type: '%s'", namespace, appType)

	// Get Kubernetes config (in-cluster or local kubeconfig)
	config, err := getKubernetesConfig()
	if err != nil {
		return fmt.Sprintf("Failed to get Kubernetes config: %v", err), err
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		return "Failed to create k8s client: " + err.Error(), err
	}

	applications := []map[string]interface{}{}

	// Get deployments as applications (most common application type)
	var deployments *appsv1.DeploymentList
	if namespace != "" {
		log.Printf("Fetching deployments from namespace: %s", namespace)
		deployments, err = clientset.AppsV1().Deployments(namespace).List(context.TODO(), metav1.ListOptions{})
	} else {
		log.Printf("Fetching deployments from all namespaces")
		deployments, err = clientset.AppsV1().Deployments("").List(context.TODO(), metav1.ListOptions{})
	}

	if err == nil {
		for _, dep := range deployments.Items {
			// Extract application information from deployment
			app := map[string]interface{}{
				"name":      dep.Name,
				"namespace": dep.Namespace,
				"type":      "deployment",
				"status":    "unknown",
				"replicas":  dep.Spec.Replicas,
				"ready":     dep.Status.ReadyReplicas,
				"available": dep.Status.AvailableReplicas,
				"age":       dep.CreationTimestamp.Time.Format("2006-01-02T15:04:05Z"),
				"labels":    dep.Labels,
			}

			// Determine status based on replica status
			if dep.Status.ReadyReplicas == *dep.Spec.Replicas && dep.Status.ReadyReplicas > 0 {
				app["status"] = "running"
			} else if dep.Status.ReadyReplicas == 0 {
				app["status"] = "stopped"
			} else {
				app["status"] = "partial"
			}

			// Get image information from containers
			if len(dep.Spec.Template.Spec.Containers) > 0 {
				app["image"] = dep.Spec.Template.Spec.Containers[0].Image
				// Extract version from image tag
				imageParts := strings.Split(app["image"].(string), ":")
				if len(imageParts) > 1 {
					app["version"] = imageParts[len(imageParts)-1]
				} else {
					app["version"] = "latest"
				}
			}

			// Add deployment-specific metadata
			app["deployment_strategy"] = string(dep.Spec.Strategy.Type)

			applications = append(applications, app)
		}
	}

	// Get StatefulSets as applications
	var statefulsets *appsv1.StatefulSetList
	if namespace != "" {
		log.Printf("Fetching statefulsets from namespace: %s", namespace)
		statefulsets, err = clientset.AppsV1().StatefulSets(namespace).List(context.TODO(), metav1.ListOptions{})
	} else {
		log.Printf("Fetching statefulsets from all namespaces")
		statefulsets, err = clientset.AppsV1().StatefulSets("").List(context.TODO(), metav1.ListOptions{})
	}

	if err == nil {
		for _, sts := range statefulsets.Items {
			app := map[string]interface{}{
				"name":      sts.Name,
				"namespace": sts.Namespace,
				"type":      "statefulset",
				"status":    "unknown",
				"replicas":  sts.Spec.Replicas,
				"ready":     sts.Status.ReadyReplicas,
				"age":       sts.CreationTimestamp.Time.Format("2006-01-02T15:04:05Z"),
				"labels":    sts.Labels,
			}

			// Determine status
			if sts.Status.ReadyReplicas == *sts.Spec.Replicas && sts.Status.ReadyReplicas > 0 {
				app["status"] = "running"
			} else if sts.Status.ReadyReplicas == 0 {
				app["status"] = "stopped"
			} else {
				app["status"] = "partial"
			}

			// Get image information
			if len(sts.Spec.Template.Spec.Containers) > 0 {
				app["image"] = sts.Spec.Template.Spec.Containers[0].Image
				imageParts := strings.Split(app["image"].(string), ":")
				if len(imageParts) > 1 {
					app["version"] = imageParts[len(imageParts)-1]
				} else {
					app["version"] = "latest"
				}
			}

			applications = append(applications, app)
		}
	}

	// Get DaemonSets as applications
	var daemonsets *appsv1.DaemonSetList
	if namespace != "" {
		log.Printf("Fetching daemonsets from namespace: %s", namespace)
		daemonsets, err = clientset.AppsV1().DaemonSets(namespace).List(context.TODO(), metav1.ListOptions{})
	} else {
		log.Printf("Fetching daemonsets from all namespaces")
		daemonsets, err = clientset.AppsV1().DaemonSets("").List(context.TODO(), metav1.ListOptions{})
	}

	if err == nil {
		for _, ds := range daemonsets.Items {
			app := map[string]interface{}{
				"name":      ds.Name,
				"namespace": ds.Namespace,
				"type":      "daemonset",
				"status":    "unknown",
				"desired":   ds.Status.DesiredNumberScheduled,
				"ready":     ds.Status.NumberReady,
				"age":       ds.CreationTimestamp.Time.Format("2006-01-02T15:04:05Z"),
				"labels":    ds.Labels,
			}

			// Determine status
			if ds.Status.NumberReady == ds.Status.DesiredNumberScheduled && ds.Status.NumberReady > 0 {
				app["status"] = "running"
			} else if ds.Status.NumberReady == 0 {
				app["status"] = "stopped"
			} else {
				app["status"] = "partial"
			}

			// Get image information
			if len(ds.Spec.Template.Spec.Containers) > 0 {
				app["image"] = ds.Spec.Template.Spec.Containers[0].Image
				imageParts := strings.Split(app["image"].(string), ":")
				if len(imageParts) > 1 {
					app["version"] = imageParts[len(imageParts)-1]
				} else {
					app["version"] = "latest"
				}
			}

			applications = append(applications, app)
		}
	}

	// Filter by app_type if specified
	if appType != "" && appType != "all" {
		filteredApps := []map[string]interface{}{}
		for _, app := range applications {
			if app["type"].(string) == appType {
				filteredApps = append(filteredApps, app)
			}
		}
		applications = filteredApps
	}

	// Log final results
	log.Printf("Found %d applications total", len(applications))

	result := map[string]interface{}{
		"success":      true,
		"namespace":    namespace,
		"app_type":     appType,
		"total_apps":   len(applications),
		"apps":         applications,
		"retrieved_at": fmt.Sprintf("%d", time.Now().Unix()),
	}

	log.Printf("Returning applications result: namespace='%s', total=%d", namespace, len(applications))
	resultBytes, _ := json.Marshal(result)
	return string(resultBytes), nil
}

// getApplicationDetailsAgent retrieves related resources for a given application name in a namespace
func getApplicationDetailsAgent(event map[string]interface{}) (string, error) {
	appName, _ := event["app_name"].(string)
	namespace, _ := event["namespace"].(string)

	if appName == "" || namespace == "" {
		return "", fmt.Errorf("app_name and namespace are required")
	}

	// Get Kubernetes config
	config, err := getKubernetesConfig()
	if err != nil {
		return fmt.Sprintf("Failed to get Kubernetes config: %v", err), err
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		return "Failed to create k8s client: " + err.Error(), err
	}

	core := clientset.CoreV1()
	related := map[string]interface{}{
		"pods":       []interface{}{},
		"services":   []interface{}{},
		"configmaps": []interface{}{},
		"secrets":    []interface{}{},
	}

	// Pods
	if pods, err := core.Pods(namespace).List(context.TODO(), metav1.ListOptions{LabelSelector: fmt.Sprintf("app=%s", appName)}); err == nil {
		for _, p := range pods.Items {
			related["pods"] = append(related["pods"].([]interface{}), p.DeepCopy())
		}
	}

	// Services
	if svcs, err := core.Services(namespace).List(context.TODO(), metav1.ListOptions{LabelSelector: fmt.Sprintf("app=%s", appName)}); err == nil {
		for _, s := range svcs.Items {
			related["services"] = append(related["services"].([]interface{}), s.DeepCopy())
		}
	}

	// ConfigMaps
	if cms, err := core.ConfigMaps(namespace).List(context.TODO(), metav1.ListOptions{LabelSelector: fmt.Sprintf("app=%s", appName)}); err == nil {
		for _, cm := range cms.Items {
			related["configmaps"] = append(related["configmaps"].([]interface{}), cm.DeepCopy())
		}
	}

	// Secrets
	if secs, err := core.Secrets(namespace).List(context.TODO(), metav1.ListOptions{LabelSelector: fmt.Sprintf("app=%s", appName)}); err == nil {
		for _, sec := range secs.Items {
			related["secrets"] = append(related["secrets"].([]interface{}), sec.DeepCopy())
		}
	}

	result := map[string]interface{}{
		"app_name":          appName,
		"namespace":         namespace,
		"related_resources": related,
	}

	rb, _ := json.Marshal(result)
	return string(rb), nil
}

// getResourceYamlAgent retrieves the YAML configuration of a Kubernetes resource
func getResourceYamlAgent(event map[string]interface{}) string {
	config, err := getKubernetesConfig()
	if err != nil {
		log.Printf("Error getting Kubernetes config: %v", err)
		return fmt.Sprintf(`{"error": "Failed to get Kubernetes config: %v"}`, err)
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		log.Printf("Error creating Kubernetes client: %v", err)
		return fmt.Sprintf(`{"error": "Failed to create Kubernetes client: %v"}`, err)
	}

	namespace, ok := event["namespace"].(string)
	if !ok {
		return `{"error": "Invalid namespace parameter"}`
	}

	resourceType, ok := event["resource_type"].(string)
	if !ok {
		return `{"error": "Invalid resource_type parameter"}`
	}

	name, ok := event["name"].(string)
	if !ok {
		return `{"error": "Invalid name parameter"}`
	}

	ctx := context.Background()

	var yamlContent string
	var resourceErr error

	switch strings.ToLower(resourceType) {
	case "deployment":
		deployment, err := clientset.AppsV1().Deployments(namespace).Get(ctx, name, metav1.GetOptions{})
		if err != nil {
			resourceErr = err
		} else {
			// Remove managed fields and resource version
			deployment.ObjectMeta.ManagedFields = nil
			deployment.ObjectMeta.ResourceVersion = ""

			yamlBytes, err := json.Marshal(deployment)
			if err != nil {
				resourceErr = err
			} else {
				yamlContent = string(yamlBytes)
			}
		}

	case "service":
		service, err := clientset.CoreV1().Services(namespace).Get(ctx, name, metav1.GetOptions{})
		if err != nil {
			resourceErr = err
		} else {
			// Remove managed fields and resource version
			service.ObjectMeta.ManagedFields = nil
			service.ObjectMeta.ResourceVersion = ""

			yamlBytes, err := json.Marshal(service)
			if err != nil {
				resourceErr = err
			} else {
				yamlContent = string(yamlBytes)
			}
		}

	case "pod":
		pod, err := clientset.CoreV1().Pods(namespace).Get(ctx, name, metav1.GetOptions{})
		if err != nil {
			resourceErr = err
		} else {
			// Remove managed fields and resource version
			pod.ObjectMeta.ManagedFields = nil
			pod.ObjectMeta.ResourceVersion = ""

			yamlBytes, err := json.Marshal(pod)
			if err != nil {
				resourceErr = err
			} else {
				yamlContent = string(yamlBytes)
			}
		}

	default:
		return fmt.Sprintf(`{"error": "Unsupported resource type: %s"}`, resourceType)
	}

	if resourceErr != nil {
		return fmt.Sprintf(`{"error": "Kubernetes API error: %v"}`, resourceErr)
	}

	result := map[string]interface{}{
		"yaml_content":  yamlContent,
		"namespace":     namespace,
		"resource_type": resourceType,
		"name":          name,
	}

	rb, _ := json.Marshal(result)
	return string(rb)
}

// updateResourceYamlAgent updates a Kubernetes resource with the provided YAML content
func updateResourceYamlAgent(event map[string]interface{}) string {
	config, err := getKubernetesConfig()
	if err != nil {
		log.Printf("Error getting Kubernetes config: %v", err)
		return fmt.Sprintf(`{"error": "Failed to get Kubernetes config: %v"}`, err)
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		log.Printf("Error creating Kubernetes client: %v", err)
		return fmt.Sprintf(`{"error": "Failed to create Kubernetes client: %v"}`, err)
	}

	namespace, ok := event["namespace"].(string)
	if !ok {
		return `{"error": "Invalid namespace parameter"}`
	}

	resourceType, ok := event["resource_type"].(string)
	if !ok {
		return `{"error": "Invalid resource_type parameter"}`
	}

	name, ok := event["name"].(string)
	if !ok {
		return `{"error": "Invalid name parameter"}`
	}

	yamlContent, ok := event["yaml_content"].(string)
	if !ok {
		return `{"error": "Invalid yaml_content parameter"}`
	}

	ctx := context.Background()

	switch strings.ToLower(resourceType) {
	case "deployment":
		var deployment appsv1.Deployment
		if err := json.Unmarshal([]byte(yamlContent), &deployment); err != nil {
			return fmt.Sprintf(`{"error": "Failed to parse deployment YAML: %v"}`, err)
		}

		// Ensure metadata fields match URL parameters
		deployment.ObjectMeta.Name = name
		deployment.ObjectMeta.Namespace = namespace

		// Get existing deployment to preserve immutable fields
		existing, err := clientset.AppsV1().Deployments(namespace).Get(ctx, name, metav1.GetOptions{})
		if err != nil {
			return fmt.Sprintf(`{"error": "Failed to get existing deployment: %v"}`, err)
		}

		// Preserve selector and template labels from existing deployment
		if existing.Spec.Selector != nil {
			deployment.Spec.Selector = existing.Spec.Selector
		}
		if existing.Spec.Template.ObjectMeta.Labels != nil {
			deployment.Spec.Template.ObjectMeta.Labels = existing.Spec.Template.ObjectMeta.Labels
		}

		// Update the deployment
		_, err = clientset.AppsV1().Deployments(namespace).Update(ctx, &deployment, metav1.UpdateOptions{})
		if err != nil {
			return fmt.Sprintf(`{"error": "Failed to update deployment: %v"}`, err)
		}

	default:
		return fmt.Sprintf(`{"error": "Unsupported resource type for update: %s"}`, resourceType)
	}

	result := map[string]interface{}{
		"success":       true,
		"namespace":     namespace,
		"resource_type": resourceType,
		"name":          name,
	}

	rb, _ := json.Marshal(result)
	return string(rb)
}

// getNodeLabelsAgent retrieves node labels from the cluster
func getNodeLabelsAgent(event map[string]interface{}) string {
	config, err := getKubernetesConfig()
	if err != nil {
		log.Printf("Error getting Kubernetes config: %v", err)
		return fmt.Sprintf(`{"error": "Failed to get Kubernetes config: %v"}`, err)
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		log.Printf("Error creating Kubernetes client: %v", err)
		return fmt.Sprintf(`{"error": "Failed to create Kubernetes client: %v"}`, err)
	}

	ctx := context.Background()

	// Check if we need labels for a specific node or all nodes
	nodeName, hasNodeName := event["node_name"].(string)

	if hasNodeName {
		// Get labels for specific node
		node, err := clientset.CoreV1().Nodes().Get(ctx, nodeName, metav1.GetOptions{})
		if err != nil {
			return fmt.Sprintf(`{"error": "Node '%s' not found: %v"}`, nodeName, err)
		}

		result := map[string]interface{}{
			"node_name": nodeName,
			"labels":    node.Labels,
		}

		rb, _ := json.Marshal(result)
		return string(rb)
	} else {
		// Get labels for all nodes
		nodes, err := clientset.CoreV1().Nodes().List(ctx, metav1.ListOptions{})
		if err != nil {
			return fmt.Sprintf(`{"error": "Failed to get nodes: %v"}`, err)
		}

		var nodesList []map[string]interface{}
		for _, node := range nodes.Items {
			nodeData := map[string]interface{}{
				"node_name": node.Name,
				"labels":    node.Labels,
			}
			nodesList = append(nodesList, nodeData)
		}

		result := map[string]interface{}{
			"nodes": nodesList,
		}

		rb, _ := json.Marshal(result)
		return string(rb)
	}
}

// getNodeDetailsAgent retrieves detailed node information from the cluster
func getNodeDetailsAgent(event map[string]interface{}) string {
	config, err := getKubernetesConfig()
	if err != nil {
		log.Printf("Error getting Kubernetes config: %v", err)
		return fmt.Sprintf(`{"error": "Failed to get Kubernetes config: %v"}`, err)
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		log.Printf("Error creating Kubernetes client: %v", err)
		return fmt.Sprintf(`{"error": "Failed to create Kubernetes client: %v"}`, err)
	}

	ctx := context.Background()

	// Check if we need details for a specific node or all nodes
	nodeName, hasNodeName := event["node_name"].(string)

	extractNodeDetails := func(node *v1.Node) map[string]interface{} {
		// Extract addresses
		addresses := make(map[string]string)
		for _, addr := range node.Status.Addresses {
			addresses[string(addr.Type)] = addr.Address
		}

		// Extract node info
		nodeInfo := map[string]interface{}{
			"osImage":                 node.Status.NodeInfo.OSImage,
			"kernelVersion":           node.Status.NodeInfo.KernelVersion,
			"kubeletVersion":          node.Status.NodeInfo.KubeletVersion,
			"containerRuntimeVersion": node.Status.NodeInfo.ContainerRuntimeVersion,
		}

		// Extract capacity
		capacity := make(map[string]interface{})
		if node.Status.Capacity != nil {
			for k, v := range node.Status.Capacity {
				capacity[string(k)] = v.String()
			}
		}

		// Extract conditions
		conditions := make(map[string]string)
		for _, cond := range node.Status.Conditions {
			conditions[string(cond.Type)] = string(cond.Status)
		}

		details := map[string]interface{}{
			"creationTimestamp": node.CreationTimestamp.Time.Format(time.RFC3339),
			"addresses":         addresses,
			"nodeInfo":          nodeInfo,
			"capacity":          capacity,
			"conditions":        conditions,
		}

		return details
	}

	if hasNodeName {
		// Get details for specific node
		node, err := clientset.CoreV1().Nodes().Get(ctx, nodeName, metav1.GetOptions{})
		if err != nil {
			return fmt.Sprintf(`{"error": "Node '%s' not found: %v"}`, nodeName, err)
		}

		result := map[string]interface{}{
			"node_name": nodeName,
			"details":   extractNodeDetails(node),
		}

		rb, _ := json.Marshal(result)
		return string(rb)
	} else {
		// Get details for all nodes
		nodes, err := clientset.CoreV1().Nodes().List(ctx, metav1.ListOptions{})
		if err != nil {
			return fmt.Sprintf(`{"error": "Failed to get nodes: %v"}`, err)
		}

		var nodesList []map[string]interface{}
		for _, node := range nodes.Items {
			nodeData := map[string]interface{}{
				"node_name": node.Name,
				"details":   extractNodeDetails(&node),
			}
			nodesList = append(nodesList, nodeData)
		}

		result := map[string]interface{}{
			"nodes": nodesList,
		}

		rb, _ := json.Marshal(result)
		return string(rb)
	}
}

// getNodeLabelsWithInsightsAgent retrieves node labels with AI-generated insights from the cluster
func getNodeLabelsWithInsightsAgent(event map[string]interface{}) string {
	config, err := getKubernetesConfig()
	if err != nil {
		log.Printf("Error getting Kubernetes config: %v", err)
		return fmt.Sprintf(`{"error": "Failed to get Kubernetes config: %v"}`, err)
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		log.Printf("Error creating Kubernetes client: %v", err)
		return fmt.Sprintf(`{"error": "Failed to create Kubernetes client: %v"}`, err)
	}

	ctx := context.Background()

	// Get labels for all nodes with insights
	nodes, err := clientset.CoreV1().Nodes().List(ctx, metav1.ListOptions{})
	if err != nil {
		return fmt.Sprintf(`{"error": "Failed to get nodes: %v"}`, err)
	}

	var nodesList []map[string]interface{}
	for _, node := range nodes.Items {
		insights := generateNodeInsights(node.Labels, &node)
		nodeData := map[string]interface{}{
			"node_name": node.Name,
			"labels":    node.Labels,
			"insights":  insights,
		}
		nodesList = append(nodesList, nodeData)
	}

	result := map[string]interface{}{
		"nodes": nodesList,
	}

	rb, _ := json.Marshal(result)
	return string(rb)
}

// generateNodeInsights generates AI-like insights based on node labels and status
func generateNodeInsights(labels map[string]string, node *v1.Node) map[string]interface{} {
	insights := map[string]interface{}{
		"node_type":       "Unknown",
		"capabilities":    []string{},
		"optimizations":   []string{},
		"alerts":          []string{},
		"recommendations": []string{},
	}

	// Analyze node type
	if arch, ok := labels["kubernetes.io/arch"]; ok {
		// Capitalize the first letter of architecture
		archCapitalized := strings.ToUpper(arch[:1]) + arch[1:]
		insights["node_type"] = fmt.Sprintf("%s Node", archCapitalized)
	}

	// Analyze capabilities based on labels
	capabilities := []string{}
	if _, ok := labels["node.kubernetes.io/instance-type"]; ok {
		capabilities = append(capabilities, "Cloud Instance")
	}
	if _, ok := labels["feature.node.kubernetes.io/cpu-cpuid.AVX"]; ok {
		capabilities = append(capabilities, "Advanced Vector Extensions (AVX)")
	}
	if _, ok := labels["feature.node.kubernetes.io/network-sriov.capable"]; ok {
		capabilities = append(capabilities, "SR-IOV Network")
	}
	if _, ok := labels["feature.node.kubernetes.io/pci-0300_10de.present"]; ok {
		capabilities = append(capabilities, "NVIDIA GPU")
	}
	if hostname, ok := labels["kubernetes.io/hostname"]; ok {
		capabilities = append(capabilities, fmt.Sprintf("Hostname: %s", hostname))
	}

	// Generate recommendations based on node analysis
	recommendations := []string{}
	if os, ok := labels["kubernetes.io/os"]; ok && os == "linux" {
		recommendations = append(recommendations, "Consider enabling container runtime security features")
	}
	if zone, ok := labels["topology.kubernetes.io/zone"]; ok {
		recommendations = append(recommendations, fmt.Sprintf("Node in %s - ensure workload distribution for high availability", zone))
	}

	// Check node conditions for alerts
	alerts := []string{}
	for _, condition := range node.Status.Conditions {
		if condition.Type == v1.NodeReady && condition.Status != v1.ConditionTrue {
			alerts = append(alerts, "Node is not ready")
		}
		if condition.Type == v1.NodeMemoryPressure && condition.Status == v1.ConditionTrue {
			alerts = append(alerts, "Node experiencing memory pressure")
		}
		if condition.Type == v1.NodeDiskPressure && condition.Status == v1.ConditionTrue {
			alerts = append(alerts, "Node experiencing disk pressure")
		}
		if condition.Type == v1.NodeNetworkUnavailable && condition.Status == v1.ConditionTrue {
			alerts = append(alerts, "Node network unavailable")
		}
	}

	// Generate optimizations based on resource capacity
	optimizations := []string{}
	if capacity := node.Status.Capacity; capacity != nil {
		if cpu := capacity["cpu"]; cpu.String() != "" {
			optimizations = append(optimizations, fmt.Sprintf("CPU Resources: %s available", cpu.String()))
		}
		if memory := capacity["memory"]; memory.String() != "" {
			optimizations = append(optimizations, fmt.Sprintf("Memory Resources: %s available", memory.String()))
		}
	}

	insights["capabilities"] = capabilities
	insights["optimizations"] = optimizations
	insights["alerts"] = alerts
	insights["recommendations"] = recommendations

	return insights
}

// getClusterResourceUsageAgent retrieves cluster resource usage metrics (CPU/Memory)
func getClusterResourceUsageAgent(event map[string]interface{}) string {
	config, err := getKubernetesConfig()
	if err != nil {
		log.Printf("Error getting Kubernetes config: %v", err)
		return fmt.Sprintf(`{"error": "Failed to get Kubernetes config: %v"}`, err)
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		log.Printf("Error creating Kubernetes client: %v", err)
		return fmt.Sprintf(`{"error": "Failed to create Kubernetes client: %v"}`, err)
	}

	ctx := context.Background()

	// Get parameters from request
	metric, _ := event["metric"].(string)
	namespace, _ := event["namespace"].(string)
	duration, _ := event["duration"].(float64)
	step, _ := event["step"].(float64)

	// Default values
	if metric == "" {
		metric = "cpu"
	}
	if namespace == "" {
		namespace = "default"
	}
	if duration == 0 {
		duration = 3600 // 1 hour
	}
	if step == 0 {
		step = 300 // 5 minutes
	}

	// Since we don't have Prometheus, we'll simulate metrics using pod data
	pods, err := clientset.CoreV1().Pods(namespace).List(ctx, metav1.ListOptions{})
	if err != nil {
		return fmt.Sprintf(`{"error": "Failed to get pods: %v"}`, err)
	} // Generate simulated time series data
	now := time.Now()
	var dataPoints []map[string]interface{}

	// Create data points for the requested duration
	numPoints := int(duration / step)
	for i := 0; i < numPoints; i++ {
		pointTime := now.Add(-time.Duration(duration-float64(i)*step) * time.Second)

		var usage float64
		if metric == "cpu" {
			// Simulate CPU usage based on number of running pods
			runningPods := 0
			for _, pod := range pods.Items {
				if pod.Status.Phase == v1.PodRunning {
					runningPods++
				}
			}
			// Simulate 10-20% CPU usage per running pod
			usage = float64(runningPods) * (0.1 + 0.1*float64(i%10)/10)
		} else if metric == "memory" {
			// Simulate memory usage
			totalPods := len(pods.Items)
			usage = float64(totalPods) * (100 + 50*float64(i%8)/8) // MB per pod
		}

		dataPoints = append(dataPoints, map[string]interface{}{
			"time":  pointTime.Format("15:04"),
			"usage": usage,
		})
	}

	result := map[string]interface{}{
		"data": dataPoints,
	}

	rb, _ := json.Marshal(result)
	return string(rb)
}

// getNodeHealthAgent retrieves node health status
func getNodeHealthAgent(event map[string]interface{}) string {
	config, err := getKubernetesConfig()
	if err != nil {
		log.Printf("Error getting Kubernetes config: %v", err)
		return fmt.Sprintf(`{"error": "Failed to get Kubernetes config: %v"}`, err)
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		log.Printf("Error creating Kubernetes client: %v", err)
		return fmt.Sprintf(`{"error": "Failed to create Kubernetes client: %v"}`, err)
	}

	ctx := context.Background()

	nodes, err := clientset.CoreV1().Nodes().List(ctx, metav1.ListOptions{})
	if err != nil {
		return fmt.Sprintf(`{"error": "Failed to get nodes: %v"}`, err)
	}

	status := map[string]int{
		"ready":     0,
		"not_ready": 0,
	}

	for _, node := range nodes.Items {
		isReady := false
		for _, condition := range node.Status.Conditions {
			if condition.Type == v1.NodeReady && condition.Status == v1.ConditionTrue {
				isReady = true
				break
			}
		}

		if isReady {
			status["ready"]++
		} else {
			status["not_ready"]++
		}
	}

	status["total"] = status["ready"] + status["not_ready"]

	rb, _ := json.Marshal(status)
	return string(rb)
}

// getSecurityOverviewAgent retrieves security vulnerability overview
func getSecurityOverviewAgent(event map[string]interface{}) string {
	config, err := getKubernetesConfig()
	if err != nil {
		log.Printf("Error getting Kubernetes config: %v", err)
		return fmt.Sprintf(`{"error": "Failed to get Kubernetes config: %v"}`, err)
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		log.Printf("Error creating Kubernetes client: %v", err)
		return fmt.Sprintf(`{"error": "Failed to create Kubernetes client: %v"}`, err)
	}

	ctx := context.Background()

	// Get all pods across all namespaces to analyze container images
	pods, err := clientset.CoreV1().Pods("").List(ctx, metav1.ListOptions{})
	if err != nil {
		return fmt.Sprintf(`{"error": "Failed to get pods: %v"}`, err)
	}

	// Since we don't have Trivy integration, simulate security scanning
	severities := []string{"Critical", "High", "Medium", "Low", "Negligible", "Unknown"}
	vulnerabilities := make(map[string]int)
	issues := []map[string]interface{}{}

	// Initialize vulnerability counts
	for _, severity := range severities {
		vulnerabilities[strings.ToLower(severity)] = 0
	}

	// Analyze container images and simulate vulnerability detection
	imageMap := make(map[string]bool)
	issueId := 1

	for _, pod := range pods.Items {
		for _, container := range pod.Spec.Containers {
			if !imageMap[container.Image] {
				imageMap[container.Image] = true

				// Simulate vulnerability scanning based on image characteristics
				imageParts := strings.Split(container.Image, ":")
				imageRepo := imageParts[0]
				imageTag := "latest"
				if len(imageParts) > 1 {
					imageTag = imageParts[1]
				}

				// Simulate findings based on image patterns
				var severity string
				var count int

				if strings.Contains(imageRepo, "nginx") || strings.Contains(imageRepo, "apache") {
					severity = "Medium"
					count = 2
				} else if strings.Contains(imageRepo, "postgres") || strings.Contains(imageRepo, "mysql") {
					severity = "High"
					count = 5
				} else if strings.Contains(imageRepo, "ubuntu") || strings.Contains(imageRepo, "debian") {
					severity = "Low"
					count = 1
				} else {
					severity = "Unknown"
					count = 0
				}

				if count > 0 {
					vulnerabilities[strings.ToLower(severity)] += count

					issues = append(issues, map[string]interface{}{
						"id":          issueId,
						"severity":    strings.ToLower(severity),
						"name":        fmt.Sprintf("CVE-%d-XXXX", 2023+issueId%3),
						"component":   fmt.Sprintf("%s:%s", imageRepo, imageTag),
						"description": fmt.Sprintf("Detected %d vulnerability(ies)", count),
					})
					issueId++
				}
			}
		}
	}

	result := map[string]interface{}{
		"lastScan":        time.Now().Format("2006-01-02T15:04:05Z"),
		"vulnerabilities": vulnerabilities,
		"issues":          issues,
	}

	rb, _ := json.Marshal(result)
	return string(rb)
}

// ===============================
// Security Policy Management Functions
// ===============================

// applySecurityPolicyAgent applies a Kyverno security policy to the cluster
func applySecurityPolicyAgent(event map[string]interface{}) (string, error) {
	log.Printf("Applying security policy: %+v", event)

	policyData, ok := event["policy_data"].(map[string]interface{})
	if !ok {
		return "", fmt.Errorf("policy_data is required")
	}

	yamlContent, ok := policyData["yaml_content"].(string)
	if !ok {
		return "", fmt.Errorf("yaml_content is required")
	}

	policyID, _ := policyData["policy_id"].(string)
	clusterName, _ := event["cluster_name"].(string)
	namespace, _ := event["namespace"].(string)

	log.Printf("Applying policy %s to cluster %s namespace %s", policyID, clusterName, namespace)

	// Apply the policy using kubectl apply (since Kyverno CRDs need special handling)
	err := applyPolicyViaKubectl(yamlContent)
	if err != nil {
		log.Printf("Failed to apply policy %s: %v", policyID, err)
		return "", fmt.Errorf("failed to apply policy: %v", err)
	}

	log.Printf("Successfully applied policy %s", policyID)

	result := map[string]interface{}{
		"success":      true,
		"message":      fmt.Sprintf("Policy %s applied successfully", policyID),
		"policy_id":    policyID,
		"cluster_name": clusterName,
		"namespace":    namespace,
		"applied_at":   time.Now().Format("2006-01-02T15:04:05Z"),
	}

	rb, _ := json.Marshal(result)
	return string(rb), nil
}

// removeSecurityPolicyAgent removes a security policy from the cluster
func removeSecurityPolicyAgent(event map[string]interface{}) (string, error) {
	log.Printf("Removing security policy: %+v", event)

	policyData, ok := event["policy_data"].(map[string]interface{})
	if !ok {
		return "", fmt.Errorf("policy_data is required")
	}

	policyID, ok := policyData["policy_id"].(string)
	if !ok {
		return "", fmt.Errorf("policy_id is required")
	}

	// Try to get the actual policy name from YAML metadata (if provided)
	policyName, ok := policyData["policy_name"].(string)
	if !ok || policyName == "" {
		policyName = policyID // Fall back to policy_id if policy_name not provided
	}

	// Get namespace if provided
	namespace, _ := event["namespace"].(string)

	clusterName, _ := event["cluster_name"].(string)

	log.Printf("Removing policy %s (name: %s) from cluster %s (namespace: %s)", policyID, policyName, clusterName, namespace)

	// Remove the policy using kubectl delete with the actual policy name
	err := removePolicyViaKubectl(policyName, namespace)
	if err != nil {
		log.Printf("Failed to remove policy %s: %v", policyName, err)
		return "", fmt.Errorf("failed to remove policy: %v", err)
	}

	log.Printf("Successfully removed policy %s", policyName)

	result := map[string]interface{}{
		"success":      true,
		"message":      fmt.Sprintf("Policy %s removed successfully", policyID),
		"policy_id":    policyID,
		"cluster_name": clusterName,
		"removed_at":   time.Now().Format("2006-01-02T15:04:05Z"),
	}

	rb, _ := json.Marshal(result)
	return string(rb), nil
}

// removeAllSecurityPoliciesAgent removes all security policies from the cluster
func removeAllSecurityPoliciesAgent(event map[string]interface{}) (string, error) {
	log.Printf("Removing ALL security policies: %+v", event)

	clusterName, _ := event["cluster_name"].(string)

	// Get list of policies to remove
	policiesData, ok := event["policies"].([]interface{})
	if !ok || len(policiesData) == 0 {
		return "", fmt.Errorf("policies list is required and cannot be empty")
	}

	log.Printf("Removing %d policies from cluster %s", len(policiesData), clusterName)

	removedPolicies := []string{}
	failedPolicies := []map[string]interface{}{}

	// Remove each policy
	for _, policyItem := range policiesData {
		policyMap, ok := policyItem.(map[string]interface{})
		if !ok {
			continue
		}

		policyID, _ := policyMap["policy_id"].(string)
		policyName, _ := policyMap["policy_name"].(string)
		namespace, _ := policyMap["namespace"].(string)

		if policyName == "" {
			policyName = policyID
		}

		log.Printf("Removing policy: %s (name: %s, namespace: %s)", policyID, policyName, namespace)

		// Remove the policy
		err := removePolicyViaKubectl(policyName, namespace)
		if err != nil {
			log.Printf("Failed to remove policy %s: %v", policyName, err)
			failedPolicies = append(failedPolicies, map[string]interface{}{
				"policy_id":   policyID,
				"policy_name": policyName,
				"error":       err.Error(),
			})
		} else {
			removedPolicies = append(removedPolicies, policyName)
			log.Printf("Successfully removed policy %s", policyName)
		}
	}

	log.Printf("Bulk removal completed: %d removed, %d failed", len(removedPolicies), len(failedPolicies))

	result := map[string]interface{}{
		"success":          len(failedPolicies) == 0, // Success only if all removed
		"message":          fmt.Sprintf("Removed %d policies from cluster %s", len(removedPolicies), clusterName),
		"cluster_name":     clusterName,
		"removed_count":    len(removedPolicies),
		"removed_policies": removedPolicies,
		"failed_count":     len(failedPolicies),
		"failed_policies":  failedPolicies,
		"removed_at":       time.Now().Format("2006-01-02T15:04:05Z"),
	}

	rb, _ := json.Marshal(result)
	return string(rb), nil
}

// listSecurityPoliciesAgent lists all Kyverno security policies in the cluster
func listSecurityPoliciesAgent(event map[string]interface{}) (string, error) {
	log.Printf("Listing security policies: %+v", event)

	clusterName, _ := event["cluster_name"].(string)

	log.Printf("Listing policies in cluster %s", clusterName)

	// List policies using kubectl get
	policies, err := listPoliciesViaKubectl()
	if err != nil {
		log.Printf("Failed to list policies: %v", err)
		return "", fmt.Errorf("failed to list policies: %v", err)
	}

	log.Printf("Found %d policies", len(policies))

	result := map[string]interface{}{
		"success":      true,
		"cluster_name": clusterName,
		"policies":     policies,
		"total":        len(policies),
		"retrieved_at": time.Now().Format("2006-01-02T15:04:05Z"),
	}

	rb, _ := json.Marshal(result)
	return string(rb), nil
}

// Helper functions for kubectl operations
func applyPolicyViaKubectl(yamlContent string) error {
	log.Printf("Applying security policy to cluster")

	// Create a temporary file for the YAML content
	tmpFile, err := os.CreateTemp("", "security-policy-*.yaml")
	if err != nil {
		return fmt.Errorf("failed to create temp file: %v", err)
	}
	defer os.Remove(tmpFile.Name()) // Clean up temp file

	// Write YAML content to temp file
	if _, err := tmpFile.WriteString(yamlContent); err != nil {
		tmpFile.Close()
		return fmt.Errorf("failed to write YAML to temp file: %v", err)
	}
	tmpFile.Close()

	log.Printf("Applying policy from temp file: %s", tmpFile.Name())
	log.Printf("YAML content:\n%s", yamlContent)

	// Apply the policy using kubectl
	cmd := exec.Command("kubectl", "apply", "-f", tmpFile.Name())
	output, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("kubectl apply failed: %v, output: %s", err, string(output))
	}

	log.Printf("Policy applied successfully: %s", string(output))
	return nil
}

func removePolicyViaKubectl(policyName string, namespace string) error {
	log.Printf("Removing policy from cluster: %s (namespace: %s)", policyName, namespace)

	if policyName == "" {
		return fmt.Errorf("policy name cannot be empty")
	}

	deleted := false

	// Try to delete as Kyverno ClusterPolicy (cluster-wide)
	cmd := exec.Command("kubectl", "delete", "clusterpolicy", policyName, "--ignore-not-found=true")
	output, err := cmd.CombinedOutput()
	if err != nil {
		log.Printf("Warning: Failed to delete Kyverno ClusterPolicy %s: %v, output: %s", policyName, err, string(output))
	} else if strings.Contains(string(output), "deleted") {
		log.Printf("Deleted Kyverno ClusterPolicy: %s", string(output))
		deleted = true
	}

	// Try to delete as Kyverno namespaced Policy
	if namespace != "" && namespace != "cluster-wide" {
		cmd = exec.Command("kubectl", "delete", "policy", policyName, "-n", namespace, "--ignore-not-found=true")
	} else {
		cmd = exec.Command("kubectl", "delete", "policy", policyName, "--all-namespaces", "--ignore-not-found=true")
	}
	output, err = cmd.CombinedOutput()
	if err != nil {
		log.Printf("Warning: Failed to delete Kyverno Policy %s: %v, output: %s", policyName, err, string(output))
	} else if strings.Contains(string(output), "deleted") {
		log.Printf("Deleted Kyverno Policy: %s", string(output))
		deleted = true
	}

	// Try to delete as KubeArmor Policy
	if namespace != "" && namespace != "cluster-wide" {
		cmd = exec.Command("kubectl", "delete", "kubearmorpolicy", policyName, "-n", namespace, "--ignore-not-found=true")
	} else {
		cmd = exec.Command("kubectl", "delete", "kubearmorpolicy", policyName, "--all-namespaces", "--ignore-not-found=true")
	}
	output, err = cmd.CombinedOutput()
	if err != nil {
		log.Printf("Warning: Failed to delete KubeArmor Policy %s: %v, output: %s", policyName, err, string(output))
	} else if strings.Contains(string(output), "deleted") {
		log.Printf("Deleted KubeArmor Policy: %s", string(output))
		deleted = true
	}

	// Try to delete as KubeArmor Host Policy (cluster-wide)
	cmd = exec.Command("kubectl", "delete", "kubearmorhostpolicy", policyName, "--ignore-not-found=true")
	output, err = cmd.CombinedOutput()
	if err != nil {
		log.Printf("Warning: Failed to delete KubeArmor Host Policy %s: %v, output: %s", policyName, err, string(output))
	} else if strings.Contains(string(output), "deleted") {
		log.Printf("Deleted KubeArmor Host Policy: %s", string(output))
		deleted = true
	}

	if deleted {
		log.Printf("Policy %s removed successfully", policyName)
	} else {
		log.Printf("Policy %s not found in cluster (may have been already deleted)", policyName)
	}

	return nil
}

func listPoliciesViaKubectl() ([]map[string]interface{}, error) {
	log.Printf("Listing real security policies from cluster")

	var allPolicies []map[string]interface{}

	// List Kyverno ClusterPolicies (cluster-wide)
	clusterPolicies, err := listKyvernoPolicies("clusterpolicies.kyverno.io", "")
	if err != nil {
		log.Printf("Warning: Failed to list Kyverno ClusterPolicies: %v", err)
	} else {
		allPolicies = append(allPolicies, clusterPolicies...)
	}

	// List Kyverno Policies in all namespaces (namespace-scoped)
	namespacedPolicies, err := listKyvernoPolicies("policies.kyverno.io", "")
	if err != nil {
		log.Printf("Warning: Failed to list Kyverno Policies: %v", err)
	} else {
		allPolicies = append(allPolicies, namespacedPolicies...)
	}

	// List KubeArmor Policies (namespace-scoped)
	kubeArmorPolicies, err := listKyvernoPolicies("kubearmorpolicies.security.kubearmor.com", "")
	if err != nil {
		log.Printf("Warning: Failed to list KubeArmor Policies: %v", err)
	} else {
		allPolicies = append(allPolicies, kubeArmorPolicies...)
	}

	// List KubeArmor Host Policies (cluster-wide)
	kubeArmorHostPolicies, err := listKyvernoPolicies("kubearmorhostpolicies.security.kubearmor.com", "")
	if err != nil {
		log.Printf("Warning: Failed to list KubeArmor Host Policies: %v", err)
	} else {
		allPolicies = append(allPolicies, kubeArmorHostPolicies...)
	}

	log.Printf("Listed %d total policies from cluster", len(allPolicies))
	return allPolicies, nil
}

// listKyvernoPolicies queries Kubernetes for Kyverno policies
func listKyvernoPolicies(resource string, namespace string) ([]map[string]interface{}, error) {
	var cmd *exec.Cmd

	if namespace == "" {
		// List cluster-wide or all namespaces
		cmd = exec.Command("kubectl", "get", resource, "-o", "json", "--all-namespaces")
	} else {
		// List in specific namespace
		cmd = exec.Command("kubectl", "get", resource, "-n", namespace, "-o", "json")
	}

	output, err := cmd.CombinedOutput()
	if err != nil {
		return nil, fmt.Errorf("kubectl command failed: %v, output: %s", err, string(output))
	}

	// Parse JSON response
	var result map[string]interface{}
	if err := json.Unmarshal(output, &result); err != nil {
		return nil, fmt.Errorf("failed to parse kubectl output: %v", err)
	}

	// Extract items from the list
	items, ok := result["items"].([]interface{})
	if !ok {
		return []map[string]interface{}{}, nil
	}

	var policies []map[string]interface{}
	for _, item := range items {
		policyMap, ok := item.(map[string]interface{})
		if !ok {
			continue
		}

		// Extract metadata
		metadata, _ := policyMap["metadata"].(map[string]interface{})
		name, _ := metadata["name"].(string)
		namespace, _ := metadata["namespace"].(string)
		creationTimestamp, _ := metadata["creationTimestamp"].(string)

		// Extract kind
		kind, _ := policyMap["kind"].(string)

		// Extract status
		status := "Unknown"
		if statusMap, ok := policyMap["status"].(map[string]interface{}); ok {
			if ready, ok := statusMap["ready"].(bool); ok && ready {
				status = "Ready"
			} else {
				status = "Not Ready"
			}
		}

		// Build policy info
		policyInfo := map[string]interface{}{
			"name":       name,
			"namespace":  namespace,
			"kind":       kind,
			"status":     status,
			"created_at": creationTimestamp,
		}

		// Set namespace to "cluster-wide" for ClusterPolicies
		if kind == "ClusterPolicy" {
			policyInfo["namespace"] = "cluster-wide"
		}

		policies = append(policies, policyInfo)
	}

	return policies, nil
}
