#!/bin/bash

# Setup kubectl for user nisha (non-sudo access)
# This script configures kubectl to work without sudo for the nisha user

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}🔧 Setting up kubectl for user 'nisha' (non-sudo access)${NC}"
echo "================================================================="

print_status() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# Check if running as nisha user
check_user() {
    if [ "$USER" != "nisha" ]; then
        print_error "This script should be run as user 'nisha', not as $USER"
        echo "Please run: su - nisha"
        echo "Then run this script again"
        exit 1
    fi
    print_status "Running as user 'nisha'"
}

# Check if k3s is installed
check_k3s() {
    if ! sudo k3s kubectl version &>/dev/null; then
        print_error "k3s is not installed or not working"
        exit 1
    fi
    print_status "k3s is installed and working"
}

# Create .kube directory for nisha user
setup_kube_config() {
    print_info "Setting up .kube directory and config..."
    
    # Create .kube directory if it doesn't exist
    mkdir -p $HOME/.kube
    
    # Copy k3s config to user's .kube directory
    sudo cp /etc/rancher/k3s/k3s.yaml $HOME/.kube/config
    
    # Change ownership to nisha user
    sudo chown $USER:$USER $HOME/.kube/config
    
    # Set proper permissions
    chmod 600 $HOME/.kube/config
    
    print_status ".kube directory and config file setup completed"
}

# Fix the server URL in kubeconfig (usually localhost needs to be changed to actual IP)
fix_kubeconfig() {
    print_info "Checking kubeconfig server URL..."
    
    # Check current server URL
    CURRENT_SERVER=$(grep server $HOME/.kube/config | awk '{print $2}')
    print_info "Current server URL: $CURRENT_SERVER"
    
    # If it's localhost or 127.0.0.1, we might need to change it
    if [[ "$CURRENT_SERVER" == *"127.0.0.1"* ]] || [[ "$CURRENT_SERVER" == *"localhost"* ]]; then
        print_warning "Server URL uses localhost - this should work for local access"
        
        # Get the actual hostname/IP
        HOSTNAME=$(hostname)
        LOCAL_IP=$(hostname -I | awk '{print $1}')
        
        print_info "Your hostname: $HOSTNAME"
        print_info "Your local IP: $LOCAL_IP"
        
        read -p "Do you want to update server URL to use hostname ($HOSTNAME)? (y/n): " -n 1 -r
        echo ""
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            # Backup original config
            cp $HOME/.kube/config $HOME/.kube/config.backup
            
            # Replace localhost with hostname
            sed -i "s|127.0.0.1|$HOSTNAME|g" $HOME/.kube/config
            print_status "Updated server URL to use $HOSTNAME"
        fi
    else
        print_status "Server URL looks good: $CURRENT_SERVER"
    fi
}

# Test kubectl access
test_kubectl() {
    print_info "Testing kubectl access..."
    
    # Test basic kubectl commands
    if kubectl version --client &>/dev/null; then
        print_status "kubectl client is working"
    else
        print_error "kubectl client test failed"
        return 1
    fi
    
    if kubectl cluster-info &>/dev/null; then
        print_status "kubectl can connect to cluster"
    else
        print_error "kubectl cannot connect to cluster"
        print_info "This might be due to network/firewall issues"
        return 1
    fi
    
    if kubectl get nodes &>/dev/null; then
        print_status "kubectl can list nodes"
        kubectl get nodes
    else
        print_error "kubectl cannot list nodes - check permissions"
        return 1
    fi
    
    if kubectl get namespaces &>/dev/null; then
        print_status "kubectl can list namespaces"
        kubectl get namespaces
    else
        print_error "kubectl cannot list namespaces"
        return 1
    fi
}

# Setup Docker access for nisha user
setup_docker_access() {
    print_info "Setting up Docker access for user 'nisha'..."
    
    # Check if docker group exists
    if getent group docker >/dev/null 2>&1; then
        print_status "Docker group exists"
    else
        print_info "Creating docker group..."
        sudo groupadd docker
    fi
    
    # Add nisha to docker group
    if groups $USER | grep -q '\bdocker\b'; then
        print_status "User 'nisha' is already in docker group"
    else
        print_info "Adding user 'nisha' to docker group..."
        sudo usermod -aG docker $USER
        print_warning "You will need to log out and log back in for docker group changes to take effect"
        print_info "Or run: newgrp docker"
    fi
    
    # Test docker access
    if docker version &>/dev/null; then
        print_status "Docker is accessible"
    else
        print_warning "Docker is not accessible yet. Try: newgrp docker"
    fi
}

# Create kubectl alias and environment setup
setup_environment() {
    print_info "Setting up environment variables and aliases..."
    
    # Add to .bashrc if not already present
    if ! grep -q "KUBECONFIG" $HOME/.bashrc; then
        echo "" >> $HOME/.bashrc
        echo "# Kubernetes configuration" >> $HOME/.bashrc
        echo "export KUBECONFIG=\$HOME/.kube/config" >> $HOME/.bashrc
        echo "alias k=kubectl" >> $HOME/.bashrc
        print_status "Added KUBECONFIG and kubectl alias to .bashrc"
    else
        print_status "Environment already configured in .bashrc"
    fi
    
    # Set for current session
    export KUBECONFIG=$HOME/.kube/config
    
    print_info "You can now use 'k' as an alias for kubectl"
}

# Show final status and next steps
show_final_status() {
    echo ""
    print_info "🎉 Setup completed! Here's what you can do now:"
    echo ""
    echo "1. Test kubectl access:"
    echo "   kubectl get nodes"
    echo "   kubectl get namespaces"
    echo ""
    echo "2. Test Docker access:"
    echo "   docker version"
    echo "   docker ps"
    echo ""
    echo "3. If Docker doesn't work, run:"
    echo "   newgrp docker"
    echo "   # or log out and log back in"
    echo ""
    echo "4. Deploy your agent:"
    echo "   cd /home/nisha/kubesage-n-agent-workflow-code/backend/agent"
    echo "   ./deploy-and-test.sh"
    echo ""
    echo "5. Use shortcuts:"
    echo "   k get pods  # 'k' is alias for kubectl"
    echo ""
    
    # Show current status
    print_info "Current status check:"
    echo "📊 Nodes:"
    kubectl get nodes 2>/dev/null || echo "Cannot access nodes"
    echo ""
    echo "📊 Namespaces:"
    kubectl get namespaces 2>/dev/null || echo "Cannot access namespaces"
    echo ""
    echo "🐳 Docker:"
    docker version --format 'Client: {{.Client.Version}}, Server: {{.Server.Version}}' 2>/dev/null || echo "Docker not accessible"
}

# Main execution
main() {
    print_info "Starting kubectl setup for user 'nisha'..."
    echo ""
    
    check_user
    check_k3s
    setup_kube_config
    fix_kubeconfig
    test_kubectl
    setup_docker_access
    setup_environment
    show_final_status
    
    echo ""
    print_status "🎉 kubectl setup completed successfully!"
    print_info "You can now use kubectl without sudo!"
}

# Handle help
if [[ "${1:-}" == "--help" ]] || [[ "${1:-}" == "-h" ]]; then
    echo "kubectl Setup Script for User 'nisha'"
    echo ""
    echo "This script configures kubectl to work without sudo for the nisha user."
    echo "It copies k3s configuration, sets proper permissions, and tests access."
    echo ""
    echo "Usage: $0"
    echo ""
    echo "Prerequisites:"
    echo "- k3s should be installed and running"
    echo "- Script should be run as user 'nisha'"
    echo ""
    exit 0
fi

# Run main function
main "$@"