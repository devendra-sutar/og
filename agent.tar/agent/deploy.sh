#!/bin/bash

set -e

echo "🚀 Deploying KubeSage Agent to Kubernetes Cluster"

# Function to check if kubectl is available
check_kubectl() {
    if ! command -v kubectl &> /dev/null; then
        echo "❌ kubectl is not installed or not in PATH"
        echo "💡 Run ./setup-kubectl-user.sh to configure kubectl for user access"
        exit 1
    fi
    echo "✅ kubectl is available"
    
    # Check if running as nisha user
    if [ "$USER" != "nisha" ]; then
        echo "⚠️  Running as user '$USER', expected 'nisha'"
        echo "💡 If you have permission issues, run ./setup-kubectl-user.sh"
    fi
}

# Function to check cluster connection
check_cluster_connection() {
    if ! kubectl cluster-info &> /dev/null; then
        echo "❌ Cannot connect to Kubernetes cluster"
        echo "💡 Possible solutions:"
        echo "   1. Run: ./setup-kubectl-user.sh"
        echo "   2. Check k3s status: sudo systemctl status k3s"
        echo "   3. Verify kubeconfig: ls -la ~/.kube/config"
        exit 1
    fi
    echo "✅ Connected to Kubernetes cluster"
}

# Function to create namespace if it doesn't exist
create_namespace() {
    local namespace=${1:-default}
    if ! kubectl get namespace "$namespace" &> /dev/null; then
        echo "📁 Creating namespace: $namespace"
        kubectl create namespace "$namespace"
    else
        echo "✅ Namespace '$namespace' already exists"
    fi
}

# Function to build Docker image
build_image() {
    echo "🔨 Building Docker image..."
    docker build -t kubesage-agent:latest .
    echo "✅ Docker image built successfully"
}

# Function to deploy manifests
deploy_manifests() {
    echo "📦 Applying Kubernetes manifests..."
    
    # Apply in order
    kubectl apply -f rbac.yaml
    echo "✅ RBAC configuration applied"
    
    kubectl apply -f configmap.yaml
    echo "✅ ConfigMap applied"
    
    kubectl apply -f secret.yaml
    echo "✅ Secret applied"
    
    kubectl apply -f deployment.yaml
    echo "✅ Deployment applied"
    
    kubectl apply -f service.yaml
    echo "✅ Service applied"
}

# Function to wait for deployment
wait_for_deployment() {
    echo "⏳ Waiting for deployment to be ready..."
    kubectl wait --for=condition=available --timeout=300s deployment/kubesage-agent
    echo "✅ Deployment is ready"
}

# Function to show status
show_status() {
    echo "📊 Deployment Status:"
    kubectl get pods -l app=kubesage-agent
    kubectl get svc kubesage-agent-service
    
    echo ""
    echo "📋 Agent Logs (last 20 lines):"
    kubectl logs -l app=kubesage-agent --tail=20 || echo "No logs available yet"
}

# Function to test agent connection to onboarding service
test_agent_connection() {
    echo "🔍 Testing agent connection to onboarding service..."
    
    POD_NAME=$(kubectl get pods -l app=kubesage-agent -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
    
    if [ -z "$POD_NAME" ]; then
        echo "❌ No running pods found"
        return 1
    fi
    
    echo "Testing with pod: $POD_NAME"
    
    # Wait and check logs for connection indicators
    echo "⏳ Waiting 60 seconds for agent to initialize..."
    sleep 60
    
    echo "📋 Checking logs for connection status..."
    LOGS=$(kubectl logs "$POD_NAME" --tail=50 2>/dev/null || echo "No logs available")
    
    if echo "$LOGS" | grep -q -E "(Agent initialized|Connected|WebSocket server|Starting agent)"; then
        echo "✅ Agent appears to be running"
    else
        echo "⚠️  Agent initialization not detected"
    fi
    
    if echo "$LOGS" | grep -q -E "(Error|Failed|Connection refused|timeout)"; then
        echo "⚠️  Connection issues detected:"
        echo "$LOGS" | grep -E "(Error|Failed|Connection refused|timeout)"
    else
        echo "✅ No obvious connection errors found"
    fi
    
    echo ""
    echo "📋 Full recent logs:"
    echo "$LOGS"
}

# Main execution
main() {
    echo "Starting KubeSage Agent deployment..."
    
    check_kubectl
    check_cluster_connection
    
    # Build image if Docker is available
    if command -v docker &> /dev/null; then
        build_image
    else
        echo "⚠️  Docker not available, assuming image is already built"
    fi
    
    deploy_manifests
    wait_for_deployment
    show_status
    test_agent_connection
    
    echo ""
    echo "🎉 KubeSage Agent deployed successfully!"
    echo ""
    echo "🔍 To check logs: kubectl logs -l app=kubesage-agent -f"
    echo "🔍 To check status: kubectl get pods -l app=kubesage-agent"
    echo "🔧 To restart: kubectl rollout restart deployment kubesage-agent"
    echo "🔍 To delete: kubectl delete -f ."
}

# Run main function
main "$@"